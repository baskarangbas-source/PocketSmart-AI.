# PocketSmart AI

Your Smart Budget & Recommendation Assistant

PocketSmart AI is a web-based budget planning project that accepts a user's budget, category and preferences and generates structured recommendations for Home Interior, Party Planning and Jewelry Planning.

## Project structure

- `app.py` - FastAPI application
- `requirements.txt` - Python dependencies
- `templates/` - web pages
- `static/` - basic styling
- `.gitignore` - files excluded from Git

## Run locally

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Start the application:

```bash
uvicorn app:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## Note

This repository is a clean starter/demo implementation prepared from the project report. Add your actual API keys and production integrations separately; do not commit secrets to GitHub.
