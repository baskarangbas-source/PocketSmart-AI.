from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path

app = FastAPI(title="PocketSmart AI")
templates = Jinja2Templates(directory=Path(__file__).parent / "templates")


def make_recommendations(category: str, budget: float, preference: str):
    budget = max(0, budget)
    if category == "Home Interior":
        allocation = [
            ("Furniture & Decor", budget * 0.45),
            ("Lighting", budget * 0.20),
            ("Storage", budget * 0.20),
            ("Accessories", budget * 0.15),
        ]
    elif category == "Party Planning":
        allocation = [
            ("Food & Catering", budget * 0.45),
            ("Decoration", budget * 0.25),
            ("Venue", budget * 0.20),
            ("Entertainment", budget * 0.10),
        ]
    else:
        allocation = [
            ("Necklace / Main Piece", budget * 0.50),
            ("Earrings", budget * 0.20),
            ("Bracelet", budget * 0.15),
            ("Accessories", budget * 0.15),
        ]

    return [
        {
            "item": item,
            "amount": round(amount, 2),
            "preference": preference or "General preference",
        }
        for item, amount in allocation
    ]


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "recommendations": None},
    )


@app.post("/recommend", response_class=HTMLResponse)
async def recommend(
    request: Request,
    category: str = Form(...),
    budget: float = Form(...),
    preference: str = Form(""),
):
    recommendations = make_recommendations(category, budget, preference)
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "recommendations": recommendations,
            "category": category,
            "budget": budget,
            "preference": preference,
        },
    )


@app.get("/health")
async def health():
    return {"status": "ok", "project": "PocketSmart AI"}
